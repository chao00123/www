<section id="button">
            <div class="banner">
                <p class="title">
                    <span class="title58">Buttons</span>
                    <br/>Easily insert buttons and call-to-actions in any page，use amazing custom
                    <br/>options to spice up your pages</p></div>
            <div class="content">
                <dl>
                    <dt class="title_sizes">
                        <h3>Button Sizes</h3></dt>
                    <dd><h6>Huge,largre,Standard and small</h6></dd>
                    <dd class="w180">
                        <button class="button button--huge button--border-radius button--size24 button--mt30 mb86">Huge</button>
                        <button class="button button--large button--border-thin button--border-radius button--size20 mt15 mb15 mb86 button--mt30">Large</button>
                        <button class="button button--Standard button--border-radius button--size16 mt20 button--mt30 mb86">Standard</button>
                        <button class="button button--Small button--border-thin-back button--border-radius button--size14 mt30 mb86 button--mt30 button1--mt30">Small</button></dd>
                </dl>
                <dl class="mt90 button--border-wire">
                    <dt class="title_sizes">
                        <h3>Button Shapss</h3></dt>
                    <dd><h6>Retangle,round,default and circle</h6></dd>
                    <dd class="w180">
                        <button class="button button--retangle button--size16 button--mt30 mb86">Retangle</button>
                        <button class="button button--round button--border-thin button--border-radius button--size16 mb86 button--mt30">Round</button>
                        <button class="button button--default button--border-radius button--size16 mt30 button--mt30 mb86">Default</button>
                        <button class="button button--circle button--border-thin-back button--border-radius50 button--size16 mb86 mt30 button--mt30">Circle</button></dd>
                </dl>
                <dl class="mt120">
                    <dt class="title_sizes mb75">
                        <h3>Winona</h3></dt>
                    <dd class="w180">
                        <button class="button button--winona button--size16 button--mt30 bg-1--button mb86" data-text="Create">
                            <span>Create</span></button>
                        <button class="button button--winona button--border-thin button--delete button--border-radius button--size16 mb86 button--mt30" data-text="Delete">
                            <span>Delete</span></button>
                        <button class="button button--winona bg-2--button button--border-radius button--inverted mb86 button--size16 mt30 button--mt30" data-text="Pubish">
                            <span>Pubish</span></button>
                        <button class="button button--winona button--border-thin-back button--buynow button--border-radius50 mb86 button--size16 mt30 button--mt30" data-text="Buy Now">
                            <span>Buy Now</span></button>
                    </dd>
                </dl>
                <dl class="mt120 button--border-wire">
                    <dt class="title_sizes mb75">
                        <h3>Ujarak</h3></dt>
                    <dd class="w160">
                        <button class="button button--ujarak button--Publish button--size16 button--mt30 bg-1--button mb86" data-text="Publish">
                            <span>Publish</span></button>
                        <button class="button button--ujarak button--border-thin button--border-radius button--size16 mb110 button--mt30" data-text="Send">
                            <span>Send</span></button>
                        <button class="button button--ujarak bg-2--button button--border-radius button--inverted mb110 button--size16 mt30 button--mt30" data-text="Confirm">
                            <span>Confirm</span></button>
                        <button class="button button--ujarak button--border-thin-back button--cancle mb110 button--border-radius50 button--size16 mt30 button--mt30" data-text="Cancle">
                            <span>Cancle</span></button>
                    </dd>
                </dl>
                <dl class="mt120">
                    <dt class="title_sizes mb75">
                        <h3>Wayra</h3></dt>
                    <dd class="w220">
                        <button class="button button--wayra button--Publish button--size16 bg-1--button mb86" data-text="Open Project">
                            <span>Open Project</span></button>
                        <button class="button button--wayra button--border-thin button--inverted button--border-radius button--size16 button--mt30 ml40" data-text="Open Project">
                            <span>Open Project</span></button>
                        <button class="button button--wayra bg-2--button button--border-radius button--inverted button--size16 button--mt30 ml40 " data-text="Open Project">
                            <span>Open Project</span></button>
                        <button class="button button--wayra button--openproject button--border-thin-back button--cancle button--border-radius50 button--size16 button--mt30 ml40" data-text="Open Project">
                            <span>Open Project</span></button>
                    </dd>
                </dl>
                <dl class="mt120 button--border-wire">
                    <dt class="title_sizes mb75">
                        <h3>Rayen</h3></dt>
                    <dd class="w180">
                        <button class="button button--rayen button--Publish button--size16 bg-1--button mb86" data-text="Question">
                            <span>Question</span></button>
                        <button class="button button--rayen button--request button--border-thin button--border-radius button--size16 button--mt30 mb86" data-text="Request">
                            <span>Request</span></button>
                        <button class="button button--rayen bg-2--button button--border-radius button--inverted button--size16 button--mt30 mb86 " data-text="Comment">
                            <span>Comment</span></button>
                        <button class="button button--rayen button--send button--border-thin-back button--cancle button--border-radius50 button--size16 button--mt30 mb86" data-text="Send">
                            <span>Send</span></button>
                    </dd>
                </dl>
                <dl class="mt120">
                    <dt class="title_sizes mb75">
                        <h3>Pipaluk</h3></dt>
                    <dd class="w180">
                        <button class="button button--pipaluk button--Publish button--archive button--size16 mb86" data-text="Archive">
                            <span>Archive</span></button>
                        <button class="button button--pipaluk button--like button--request button--border-radius button--size16 button--mt30 mb86" data-text="Like">
                            <span>Like</span></button>
                        <button class="button button--pipaluk button--addtocart button--border-radius button--inverted button--size16 button--mt30 mb86 " data-text="Add To Cart">
                            <span>Add To Cart</span></button>
                        <button class="button button--pipaluk button--buy button--border-radius50 button--size16 button--mt30 mb86" data-text="Buy">
                            <span>Buy</span></button>
                    </dd>
                </dl>
                <dl class="mt120 button--border-wire">
                    <dt class="title_sizes mb75">
                        <h3>Wapasha</h3></dt>
                    <dd class="w180">
                        <button class="button button--wapasha button--back button--size16 mb86" data-text="Back">
                            <span>Back</span></button>
                        <button class="button button--wapasha button--hold button--border-radius button--size16 button--mt30 mb86" data-text="Hold">
                            <span>Hold</span></button>
                        <button class="button button--wapasha button--follow button--border-radius button--size16 button--mt30 mb86 " data-text="Follow">
                            <span>Follow</span></button>
                        <button class="button button--wapasha button--next button--border-radius50 button--size16 button--mt30 mb86" data-text="Next">
                            <span>Next</span></button>
                    </dd>
                </dl>
                <dl class="mt120">
                    <dt class="title_sizes mb75">
                        <h3>Shikoba</h3></dt>
                    <dd class="w150">
                        <button class="button button--shikoba button--hide button--size16 mb86" data-text="Hide">
                            <i class="glyphicon glyphicon-home"></i>
                            <span>Hide</span></button>
                        <button class="button button--shikoba button--filter button--border-radius button--size16 button--mt30 mb125" data-text="Filter">
                            <i class="glyphicon glyphicon-road"></i>
                            <span>Filter</span></button>
                        <button class="button button--shikoba button--add button--border-radius button--size16 button--mt30 mb125" data-text="Add">
                            <i class="glyphicon glyphicon-repeat"></i>
                            <span>Add</span></button>
                        <button class="button button--shikoba button--create button--border-radius50 button--size16 button--mt30 mb125" data-text="Create">
                            <i class="glyphicon glyphicon-glass"></i>
                            <span>Create</span></button>
                    </dd>
                </dl>
                <dl class="mt120 button--border-wire2">
                    <dt class="title_sizes mb75">
                        <h3>Nina</h3></dt>
                    <dd class="w180">
                        <button class="button button--nina button--sendmail button--size16 mb86" data-text="Send mail">
                            <span>S</span><span>e</span><span>n</span><span>d</span> <span>m</span><span>a</span><span>i</span><span>l</span></button>
                        <button class="button button--nina button--deletearticle button--border-radius button--size16 button--mt30 mb86" data-text="Delete article">
                            <span>D</span><span>e</span><span>l</span><span>e</span><span>t</span><span>e</span> <span>a</span><span>r</span><span>t</span><span>i</span><span>c</span><span>l</span><span>e</span></button>
                        <button class="button button--nina button--checkout button--border-radius button--size16 button--mt30 mb86" data-text="Check out">
                            <span>C</span><span>h</span><span>e</span><span>c</span><span>k</span> <span>o</span><span>u</span><span>t</span></button>
                        <button class="button button--nina button--download button--border-radius50 button--size16 button--mt30 mb86" data-text="Download">
                            <span>D</span><span>o</span><span>w</span><span>n</span><span>l</span><span>o</span><span>a</span><span>d</span></button>
                    </dd>
                </dl>
            </div>
        </section>

