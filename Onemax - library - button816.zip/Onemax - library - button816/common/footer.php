
<footer id="footer" class="container-fluid">
    <div class="container">
        <div class="row mg9 text-left">
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="section1_logo"></div>
                <div class="inner_section1_content mg3">
                    <h6>Our clean, well commented code means you can spend less time building your options page, and more time focussed on your project.Carefully built to ensure maximum compatibility no matter how your customers choose to experience the web!We believe in giving back to the community... and so do our users! Redux is proud to be 100% Open Source!</h6></div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="footer_title">
                    <a href="#">
                        <h4>Latest News</h4></a>
                </div>
                <div class="media mg3">
                    <div class="media-left">
                        <a href="#">
                            <img class="media-object" src="<?php bloginfo('template_url');?>/img/footer_news1.jpg" alt="news1"></a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading">
                            <a href="#">Your Title Here</a></h4>
                        <a href="#">
                            <h6>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus</h6></a>
                    </div>
                </div>
                <div class="line mg2"></div>
                <div class="media mg3">
                    <div class="media-left">
                        <a href="#">
                            <img class="media-object" src="<?php bloginfo('template_url');?>/img/footer_news2.jpg" alt="news1"></a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading">
                            <a href="#">Your Title Here</a></h4>
                        <a href="#">
                            <h6>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus</h6></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="footer_title">
                    <a href="#">
                        <h4>Need Help?</h4></a>
                </div>
                <div class="help_list mg1">
                    <ul class="list-unstyled">
                        <li>
                            <a href="#">
                                <h5>Where can I find my Purchase</h5></a>
                        </li>
                        <li>
                            <a href="#">
                                <h5>How does the this work?</h5></a>
                        </li>
                        <li>
                            <a href="#">
                                <h5>Quick Answers - Help FAQ</h5></a>
                        </li>
                    </ul>
                </div>
                <div class="footer_title mg2">
                    <a href="#">
                        <h4>Categories</h4></a>
                </div>
                <div class="Categories_list mg2">
                    <ul class="list-unstyled list-inline">
                        <li>
                            <a href="#">
                                <h5>Html5</h5></a>
                        </li>
                        <li class="active">
                            <a href="#">
                                <h5>PHP</h5></a>
                        </li>
                        <li>
                            <a href="#">
                                <h5>ASP</h5></a>
                        </li>
                        <li>
                            <a href="#">
                                <h5>CSS3</h5></a>
                        </li>
                    </ul>
                    <ul class="list-unstyled list-inline">

                        <li>
                            <a href="#">
                                <h5>VBScript</h5></a>
                        </li>
                        <li>
                            <a href="#">
                                <h5>Javascript</h5></a>
                        </li>
                        <li>
                            <a href="#">
                                <h5>XML</h5></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="footer_title">
                    <a href="#">
                        <h4>Contact Us</h4></a>
                </div>
                <address class="mg2 contact">
                    <h5>1600 Pennsylvania Avenue NWWashington,DC 20500
                        <br>
                        <div class="mg2"></div>
                        <a href="mailto:#">Email: email@yourdomain.com</a>
                        <br>Phone1: +001 111 1111 111
                        <br>Phone2: +001 222 2222 222
                        <br>Fax: +001 888 8888 888</h5></address>
                <div class="line mg2"></div>
                <div class="row mg3 row-centered">
                    <div class="col-lg-2 col-xs-2 col-centered">
                        <div class="social_icon social_icon1">
                            <a href="#"></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-xs-2 col-centered">
                        <div class="social_icon social_icon2">
                            <a href="#"></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-xs-2 col-centered">
                        <div class="social_icon social_icon3">
                            <a href="#"></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-xs-2 col-centered">
                        <div class="social_icon social_icon4">
                            <a href="#"></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-xs-2 col-centered">
                        <div class="social_icon social_icon5">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="foot_nav row mg9">
        <div class="foot_nav_innnerline"></div>
        <div class="container text-center">
            <span class="copyright">Copyright © 2015 | Designed by Oliver</span>
        </div>
    </div>


</footer>
</body>

</html>
