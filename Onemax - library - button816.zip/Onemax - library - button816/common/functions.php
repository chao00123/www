<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link type="text/css" rel="stylesheet" href=" <?php bloginfo('template_url');?>/css/bootstrap/bootstrap.css" />
<link type="text/css" rel="stylesheet" href=" <?php bloginfo('template_url');?>/css/nav_footer.css" />
<link type="text/css" rel="stylesheet" href=" <?php bloginfo('template_url');?>/css/coporment/button/button.css" />
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery-2.1.3.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/bootstrap/bootstrap.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/coporment/button/button_min.js "></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
	$("#sidebar").scroll_navi();
	
}); 	
</script>
<link rel="icon" href="/favicon.ico">