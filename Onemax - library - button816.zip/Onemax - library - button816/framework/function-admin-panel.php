<?php

/*
@package onemax wordpress themes
================================
Admin page
================================
*/

function onemax_add_option_panel(){
  //Generate OneMax Admin panel menu
  add_menu_page('OneMax Theme Panel','OneMax','manage_options','YYDesign_OneMax_Option_Page','OneMax_theme_setting', get_template_directory_uri() . '/img/onemax_option_icon.png', 110);
  //Generate OneMax Admin panel sub menu
  add_submenu_page('YYDesign_OneMax_Option_Page','OneMax Theme Panel','Theme Setting','manage_options','YYDesign_OneMax_Option_Page','OneMax_theme_setting');
  add_submenu_page('YYDesign_OneMax_Option_Page','OneMax Theme Panel','Inport Demo','manage_options','YYDesign_Onemax_Inport_Demo','onemax_inport_demo');
// add custom setting
add_action('admin_init','onemax_custom_setting');
}
add_action('admin_menu','onemax_add_option_panel');

function onemax_custom_setting(){
register_setting('onemax-setting-pool','first_name');
}

function OneMax_theme_setting(){
  require_once( get_template_directory() . '/framework/inc/function-option-panel.php');
}

function onemax_inport_demo(){
  require_once (get_template_directory() .'/framework/inc/function-onemax_importer.php') ;
}
